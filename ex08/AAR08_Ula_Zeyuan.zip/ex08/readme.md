# AI robotics Group Assignment

## Team Members
- **Ula Sveiteryte**
- **Yu Zeyuan**

## How to
**just run the .py file**

